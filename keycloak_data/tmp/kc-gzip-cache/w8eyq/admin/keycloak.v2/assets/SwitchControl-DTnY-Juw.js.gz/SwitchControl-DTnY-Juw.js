import{jsx as a}from"react/jsx-runtime";import{a as r,Z as n}from"./main-sXGQCNIf.js";const l=t=>{const{t:o}=r();return a(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-DTnY-Juw.js.map
