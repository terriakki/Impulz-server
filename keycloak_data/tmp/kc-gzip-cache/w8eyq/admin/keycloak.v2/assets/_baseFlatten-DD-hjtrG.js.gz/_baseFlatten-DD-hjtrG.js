import{e4 as t,dl as f,e5 as h,e6 as d}from"./main-sXGQCNIf.js";var o=t?t.isConcatSpreadable:void 0;function m(n){return f(n)||h(n)||!!(o&&n&&n[o])}function p(n,g,e,r,a){var s=-1,b=n.length;for(e||(e=m),a||(a=[]);++s<b;){var i=n[s];e(i)?d(a,i):r||(a[a.length]=i)}return a}export{p as b};
//# sourceMappingURL=_baseFlatten-DD-hjtrG.js.map
