import{useMemo as o}from"react";import{d as a,eV as s}from"./main-sXGQCNIf.js";function u(){const{realmRepresentation:e}=a(),t=o(()=>e?.supportedLocales?.length?e.supportedLocales:[s],[e]),r=o(()=>e?.defaultLocale?.length?[e.defaultLocale]:[],[e]);return o(()=>Array.from(new Set([...r,...t])),[r,t])}export{u};
//# sourceMappingURL=useLocale-SybeFFRc.js.map
