import{cO as o}from"./main-sXGQCNIf.js";const s=t=>r=>r&&o(t,r)||"—";export{s as t};
//# sourceMappingURL=translationFormatter-DwlO6F86.js.map
