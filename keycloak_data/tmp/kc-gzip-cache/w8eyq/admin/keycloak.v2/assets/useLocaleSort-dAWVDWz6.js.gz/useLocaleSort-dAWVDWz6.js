import{dy as l}from"./main-sXGQCNIf.js";function i(){const{whoAmI:o}=l();return function(c,t){const a=o.getLocale();return[...c].sort((s,u)=>{const n=t(s),r=t(u);return n===void 0||r===void 0?0:n.localeCompare(r,a)})}}const m=o=>e=>e[o];export{m,i as u};
//# sourceMappingURL=useLocaleSort-dAWVDWz6.js.map
