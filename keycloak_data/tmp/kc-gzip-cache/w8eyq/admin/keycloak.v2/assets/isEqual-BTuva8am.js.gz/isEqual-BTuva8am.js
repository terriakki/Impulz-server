import{eU as s}from"./main-sXGQCNIf.js";function i(a,r){return s(a,r)}export{i};
//# sourceMappingURL=isEqual-BTuva8am.js.map
