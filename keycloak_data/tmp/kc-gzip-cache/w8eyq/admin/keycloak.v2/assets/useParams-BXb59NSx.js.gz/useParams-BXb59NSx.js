import{c as s}from"./main-sXGQCNIf.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-BXb59NSx.js.map
